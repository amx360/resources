var $dashapp = (() => {

    var api = 'dashboardtv';
    var geturl = (resource) => '/' + api + '/' + resource;
    var dashkey = $('#dashkey').val();
    var pageid = () => $('#dashpageid').val();
    var environment = $('#environment').val();
    var storagekey = 'aes-dashtvsettings';
    var _worker;
    var _workerjs = '../Mock/js/notify-worker.js';

    var getWorkerUpdateTm = () => {
        var val = $('#workerupdatedtm').val();
        return parseInt(val);
    }

    var updateWorkerUpdateTm = (value) => {
        $('#workerupdatedtm').val(value);
    }

    var getNow = () => new Date().getTime();

    var getTimeOffset = () => new Date().getTimezoneOffset();

    var getNowLocaleString = () => new Date().toLocaleString();

    var iserror = () => dashkey.includes('error');

    var iniAsync = async() => {
        if (environment === "live") {
            await iniliveAsync();
        } else {
            await inidemoAsync();
        }
    }

    var iniliveAsync = async() => {
        fetchSettingsAsync(pageid())
        .then(response => setContentAsync())
        .catch((error) => {
                console.log(error);
            })
        .finally(() => {});

     if (iserror()) return;

     await new Promise(resolve => setTimeout(resolve, 1000)); 
     await monitorUpdatesAsync();
    }

    var monitorUpdatesAsync = async() => {
        while(true) {
           
           
            var waittms = $dashapp.getWorkerUpdateTm();
            if (waittms.toString() !== 'NaN'){
                console.log('worker waiting for: ' + waittms.toString());
                await new Promise(resolve => setTimeout(resolve, waittms)); 
                updatePageAsync()
                .catch((error) => {
                      //don't crash the application
                    console.log(error);
                    //try again on next interval
                });
            }
        }
    }

    var inidemoAsync = async() => {
        await setContentAsync();
    }

    var setContentAsync = async() => {
        var contentcss = '.dash-content-' + dashkey;
        $(contentcss).css("display", "block");

        if (environment === 'live') {
            if (!iserror()) {
                updatePageAsync()
                .catch((error) => {
                        console.log(error);
                    })
                .finally(() => {});
            }
        } else if (environment === 'demo') {

        } else if (environment === 'mockup') {
            var header = 'Demo ' + '<small> ' + dashkey.toUpperCase() + '</small>';
            $('#dashheader > h1').html(header);
        }
    }

    var startWorker = () => {
        //don't crash the application
        if (iserror()) 
            return;

        if (typeof(Worker) !== "undefined") {
            if (typeof(_worker) == "undefined") {
                _worker = new Worker(_workerjs);
            }
            _worker.onmessage = async (e) => {
                e.preventDefault();
                var waittms = $dashapp.getWorkerUpdateTm();

                console.log('waiting for: ' + waittms.toString());

                await new Promise(resolve => setTimeout(resolve, waittms)); 

                updatePageAsync()
                .catch((error) => {
                      //don't crash the application
                    console.log(error);
                    //try again on next interval
                })
                .finally(() => {
                    console.log('Worker updated DS');
                });

            };
        } else {
            console.log("No Web Worker support.");
        }

    }

    var stopWorker = () => {
        _worker.terminate();
        _worker = undefined;
    }

    var fetchSettingsAsync = async(pageid) => {
        var data = {
            pageid: pageid,
            useroffset: getTimeOffset(),
            usertime: getNow()
        };
        let url = geturl("getpagesettings");
        return await new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: $dashapp.getFormData(data),
                success: (response) => {
                    if (response.status === "false") {
                        reject(response.message);
                    } else {
                        $dashapp.setupPageSettings(response.settings);
                        $dashapp.saveSettings(response.settings);
                        resolve(true);
                    }
                },
                error: (error) => {
                    reject(error);
                }
            });

        });
    }

    var saveSettings = (data) => {
        localStorage.setItem(storagekey, JSON.stringify(data));
    }

    var getSettings = () => {
        var settings = JSON.parse(localStorage.getItem(storagekey));
        return settings;
    }

    var updatePageAsync = async() => {
        return await new Promise((resolve, reject) => {
            var settings = $dashapp.getSettings();
            $.each(settings.items, (i, item) => {
                $dashapp.updatePageItemAsync(settings.items[i])
                .then((response) =>  setHeaderTimeStamp() )
                .catch((error) => {
                        reject(error);
                });
            });

            resolve(true);
        });
    }

    var updatePageItemAsync = async(item) => {

        let data = {
            pageid: item.pageid,
            itemid: item.id,
            useroffset: getTimeOffset(),
            usertime: getNow()
        };

        if (data.itemid === undefined) throw new Error("data.itemid is undefined");
        if (data.itemid === null) throw new Error("data.itemid is null");
        if (data.itemid === '') throw new Error("data.itemid is empty");

        let selector = '#' + item.containerid;
        let url = geturl("getPageItemData");
        return await new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: $dashapp.getFormData(data),
                beforeSend: () => showLoadingInBoxItem(selector),
                success: (response) => {
                    if (response.status === "false") {
                        hideLoadingInBoxItem(selector);
                        reject(response.message);
                    } else {
                        updateBoxItemData(selector, response.item);
                        hideLoadingInBoxItem(selector);
                        resolve(true);
                    }
                },
                error: (error) => {
                    hideLoadingInBoxItem(selector);
                    reject(error);
                }
            });
        });
    }

    var updateBoxItemData = (itemselector, item) => {

        var content = $(itemselector + ' > ' + 'div.dash-box-content');

        var span = $(content)
            .find("div:first")
            .find("span:first");

        $(span).text(item.num);
    }

    var setupPageSettings = (settings) => {
        hideAllItemBoxes();
        if (settings === undefined) return;
        if (settings === null) return;
        updateWorkerUpdateTm(settings.updatems);
        setupItems(settings.items);
        if (settings.showheaderts === 'true'){
            showHeaderTimeStamp();
        }
    }

    var setupItems = (items) => {
        if (items === undefined) return;
        if (items === null) return;
        $.each(items, (i, item) => {
            var selector = '#' + items[i].containerid;
            setupBoxItemData(selector, items[i]);
        });
    }

    var setupBoxItemData = (itemselector, item) => {

        addClassToElement($(itemselector), item.containercss);
        setBoxItemIcon($(itemselector), item.iconcss);

        var content = $(itemselector + ' > ' + 'div.dash-box-content');

        var span = $(content)
            .find("div:first")
            .find("span:first");

        $(span).text(item.num);

        span = $(content)
            .find("div:last")
            .find("span:first");

        $(span).text(item.text);
    }

    var showLoadingInBoxItem = (itemselector) => {
        $(itemselector + ' > ' + 'div.overlay').css('display', 'block');
    }

    var hideLoadingInBoxItem = (itemselector) => {
        $(itemselector + ' > ' + 'div.overlay').css('display', 'none');
    }

    var getFormData = (object) => {
        const formData = new FormData();
        Object.keys(object).forEach(key => formData.append(key, object[key]));
        return formData;
    }

    var addClassToElement = (ele, classes) => {
        if (classes === undefined) return;
        if (classes === null) return;
        if (classes === '') return;
        var delimiter = ' ';
        var values = classes.split(delimiter);
        if (values.length == 0) return;
        $(ele).removeClass();
        for (var i = 0; i < values.length; i++) {
            if (!$(ele).hasClass(values[i])) {
                $(ele).addClass(values[i]);
            }
        }
    }

    var setBoxItemIcon = (boxelement, classes) => {
        if (classes === undefined) return;
        if (classes === null) return;
        if (classes === '') return;
        $(boxelement).find('span:first').find('i:first').removeClass();
        $(boxelement).find('span:first').find('i:first').addClass(classes);
    }

    var setHeaderTimeStamp = ()=>{
        $('#dashheader-ts').text(getNowLocaleString());
    }

    var showHeaderTimeStamp = () => {
        if ($('#dashheader-ts').hasClass('hidden'))
        {
            $('#dashheader-ts').removeClass('hidden')
        }
    }

    var hideAllItemBoxes = () => {
        $('[id^="item-box"]').addClass('hidden');
    }

    return {
        iniAsync: iniAsync,
        iniliveAsync: iniliveAsync,
        inidemoAsync: inidemoAsync,
        monitorUpdatesAsync:monitorUpdatesAsync,
        getWorkerUpdateTm: getWorkerUpdateTm,
        updateWorkerUpdateTm: updateWorkerUpdateTm,
        getNow: getNow,
        startWorker: startWorker,
        stopWorker: stopWorker,
        setContentAsync: setContentAsync,
        saveSettings: saveSettings,
        getSettings: getSettings,
        fetchSettingsAsync: fetchSettingsAsync,
        updatePageAsync: updatePageAsync,
        updatePageItemAsync: updatePageItemAsync,
        getFormData: getFormData,
        updateBoxItemData: updateBoxItemData,
        setupBoxItemData: setupBoxItemData,
        setupPageSettings: setupPageSettings,
        addClassToElement: addClassToElement,
        setBoxItemIcon: setBoxItemIcon,
        setHeaderTimeStamp:setHeaderTimeStamp,
        showHeaderTimeStamp:showHeaderTimeStamp
    }
})();



$(async() => {
    var attachFastClick = Origami.fastclick;
    attachFastClick(document.body);

    await $dashapp.iniAsync();

    //$('[data-toggle="tooltip"]').tooltip()
});