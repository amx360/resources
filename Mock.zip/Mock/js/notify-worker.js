var wrk_i = 0;

function timedCount() {
    wrk_i = wrk_i + 1;
  postMessage(wrk_i);
  setTimeout("timedCount()",500);
}

timedCount();